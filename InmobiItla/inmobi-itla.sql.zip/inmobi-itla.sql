--
-- Base de datos: `inmobi-itla`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `tipo_producto_id` int(50) NOT NULL,
  `precio` decimal(13,3) NOT NULL,
  `tipo_acciones_id` varchar(50) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `cantidad` int(255) NOT NULL,
  `ubicacion` geometry NOT NULL,
  `fotos` varbinary(8000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `titulo`, `direccion`, `tipo_producto_id`, `precio`, `tipo_acciones_id`, `descripcion`, `cantidad`, `ubicacion`, `fotos`) VALUES
(1, 'Mueble', 'Carretera Mella', 0, '150000.000', 'vender', 'esta como nuevo', 0, '\0\0\0\0\0\0\0\0\0\0\0\0\0�?\0\0\0\0\0\0�?', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_productos`
--

CREATE TABLE `tipos_productos` (
  `tipo_producto_id` int(11) NOT NULL,
  `tipo_producto_display` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipos_productos`
--

INSERT INTO `tipos_productos` (`tipo_producto_id`, `tipo_producto_display`) VALUES
(1, 'Casa'),
(2, 'Apartamento');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_usuarios`
--

CREATE TABLE `tipos_usuarios` (
  `tipo_usuario_id` int(11) NOT NULL,
  `tipo_usuario_name` varchar(255) NOT NULL,
  `tipo_usuario_display` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipos_usuarios`
--

INSERT INTO `tipos_usuarios` (`tipo_usuario_id`, `tipo_usuario_name`, `tipo_usuario_display`) VALUES
(1, 'USER', 'Usuario'),
(2, 'ADMIN', 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_acciones`
--

CREATE TABLE `tipo_acciones` (
  `tipo_acciones_id` int(11) NOT NULL,
  `tipo_acciones_display` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipo_acciones`
--

INSERT INTO `tipo_acciones` (`tipo_acciones_id`, `tipo_acciones_display`) VALUES
(1, 'Vender'),
(2, 'Alquilar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `cedula` varchar(11) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `primernombre` varchar(255) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `telefono` varchar(11) NOT NULL,
  `celular` varchar(11) NOT NULL,
  `fax` varchar(11) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `tipo_usuario_id` int(11) NOT NULL,
  `habilitado` tinyint(1) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `mas_informacion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `cedula`, `correo`, `nombre`, `primernombre`, `apellido`, `telefono`, `celular`, `fax`, `clave`, `tipo_usuario_id`, `habilitado`, `foto`, `mas_informacion`) VALUES
(8, '001-0251121', 'dimasariel73@gmail.com', 'DimasAriel', 'Dimas Ariel', 'Aguero', '8094837302', '8298569216', '8298569216', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, '', 'MI PAGINA');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipos_productos`
--
ALTER TABLE `tipos_productos`
  ADD PRIMARY KEY (`tipo_producto_id`);

--
-- Indices de la tabla `tipos_usuarios`
--
ALTER TABLE `tipos_usuarios`
  ADD PRIMARY KEY (`tipo_usuario_id`);

--
-- Indices de la tabla `tipo_acciones`
--
ALTER TABLE `tipo_acciones`
  ADD PRIMARY KEY (`tipo_acciones_id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `tipos_productos`
--
ALTER TABLE `tipos_productos`
  MODIFY `tipo_producto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipos_usuarios`
--
ALTER TABLE `tipos_usuarios`
  MODIFY `tipo_usuario_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipo_acciones`
--
ALTER TABLE `tipo_acciones`
  MODIFY `tipo_acciones_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
